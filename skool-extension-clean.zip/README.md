# Skool Token Extractor - Chrome Extension

## Overview

This Chrome extension extracts Client ID and JWT token from your Skool session for use with the Skool Public Group Checker API.

## Features

✅ **Automatic Token Extraction** - Extracts tokens from Skool cookies
✅ **JWT Validation** - Decodes and validates JWT tokens
✅ **Expiry Tracking** - Shows when tokens expire
✅ **One-Click Copy** - Copy tokens to clipboard
✅ **Direct API Integration** - Send tokens directly to your API

## Installation

### Method 1: Developer Mode (Recommended for Development)

1. Download or clone this repository
2. Open Chrome and navigate to `chrome://extensions/`
3. Enable "Developer mode" in the top right
4. Click "Load unpacked"
5. Select the `chrome-extension/` folder

### Method 2: Production (Coming Soon)

Will be available on Chrome Web Store.

## Usage

1. **Login to Skool**
   - Go to https://www.skool.com
   - Login with your account

2. **Open Extension**
   - Click the extension icon in Chrome toolbar
   - Tokens will be automatically extracted

3. **Use Tokens**
   - **Copy**: Click "Copy Tokens to Clipboard" to copy tokens
   - **Send to API**: Click "Send to API" to validate tokens with your API

## Security

⚠️ **Important Security Notes:**

- Tokens are extracted from your active Skool session
- Never share your tokens with others
- Tokens expire after ~6 months
- Extension runs locally and doesn't send data anywhere except your specified API endpoint

## Token Information

### Client ID
- Static identifier for your Skool account
- Format: 32-character hex string
- Example: `d1b32d9aec744fb28c3de538c5aa7aad`

### JWT Token
- JSON Web Token for authentication
- Contains: user_id, issued_at (iat), expires_at (exp)
- Lifetime: ~6 months from issuance
- Example payload:
  ```json
  {
    "user_id": "04b02f5028534735ae60bf414465b766",
    "iat": 1754996909,
    "exp": 1786532909
  }
  ```

## API Integration

### Validate Tokens

Send tokens to your API endpoint:

```bash
curl -X POST http://localhost:8000/auth/validate \
  -H "Content-Type: application/json" \
  -d '{
    "client_id": "d1b32d9aec744fb28c3de538c5aa7aad",
    "jwt_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }'
```

Response:
```json
{
  "valid": true,
  "user_id": "04b02f5028534735ae60bf414465b766",
  "expires_at": "2026-12-16T00:00:00",
  "issued_at": "2025-01-16T00:00:00",
  "client_id": "d1b32d9aec744fb28c3de538c5aa7aad"
}
```

## Troubleshooting

### "Not logged in to Skool"
- Make sure you're logged in to Skool in the current browser
- Try refreshing the page
- Check that cookies are enabled

### "Token has expired"
- Login to Skool again to refresh tokens
- New tokens will be automatically extracted

### "Failed to send to API"
- Make sure your API server is running
- Check CORS settings on your API server
- Verify the API endpoint URL is correct

## Development

### File Structure

```
chrome-extension/
├── manifest.json       # Extension configuration
├── popup.html          # Extension popup UI
├── popup.js            # Extension logic
├── icons/              # Extension icons
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md           # This file
```

### Permissions

- `cookies`: Required to read Skool cookies
- `activeTab`: Required for current tab access
- `storage`: Required for storing preferences (future)
- `host_permissions`: Required for Skool domain access

## License

MIT License

## Author

[zaharenok](https://github.com/zaharenok)

## Support

For issues or questions:
- GitHub Issues: https://github.com/zaharenok/Skool_app2/issues
- Documentation: See main README_API.md
