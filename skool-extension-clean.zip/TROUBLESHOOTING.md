# 🔧 Chrome Extension Troubleshooting

**Проблема:** Popup не активен, не работает или серый/неактивный

---

## 🐛 Возможные проблемы и решения

### Проблема 1: ❌ Файл popup.js отсутствует

**Симптомы:**
- Popup открывается, но пустой или показывает только HTML
- Кнопки не работают
- Консоль (F12) показывает ошибку: `Failed to load resource`

**Решение:**

Создайте файл `popup.js` в папке `chrome-extension/`:

```javascript
document.addEventListener('DOMContentLoaded', function() {
    console.log('Skool Token Extractor loaded');

    const statusDiv = document.getElementById('status');
    const tokensContent = document.getElementById('tokens-content');

    // Get cookies from skool.com
    chrome.cookies.getAll({domain: '.skool.com'}, function(cookies) {
        const authTokenCookie = cookies.find(c => c.name === 'auth_token');

        if (!authTokenCookie) {
            showStatus('error', 'Please login to Skool first!');
            return;
        }

        // Display tokens...
    });
});
```

**Уже исправлено!** ✅

---

### Проблема 2: ⚠️ Manifest V3 Service Worker неактивен

**Симптомы:**
- В `chrome://extensions/` показывает "service worker (Inactive)"
- Popup не работает

**Решение:**

**Это НОРМАЛЬНО!** Service worker в Manifest V3 активируется только когда нужен.

Для popup расширения service worker **не требуется**.

---

### Проблема 3: 🔒 Нет прав на cookies

**Симптомы:**
- Popup показывает "No auth_token found"
- Вы залогинены на Skool

**Решение:**

1. Проверьте `manifest.json` - должно быть:
```json
{
  "permissions": [
    "cookies",
    "activeTab"
  ],
  "host_permissions": [
    "https://www.skool.com/*"
  ]
}
```

2. Перезагрузите расширение:
   - Откройте `chrome://extensions/`
   - Нажмите кнопку "Reload" на расширении

**Уже правильно!** ✅

---

### Проблема 4: 🌐 Не на skool.com

**Симптомы:**
- Popup показывает "Please login to Skool first!"

**Решение:**

1. Откройте https://www.skool.com
2. Залогиньтесь
3. Обновите popup (нажмите на иконку расширения)

---

### Проблема 5: 🔄 Кэширование после обновления

**Симптомы:**
- Изменения в коде не применяются
- Показывается старая версия

**Решение:**

1. `chrome://extensions/`
2. Нажмите "Reload" 🔄
3. Или удалите и установите занов

---

## 🔍 Как проверить что расширение работает

### 1. Проверить консоль

1. Откройте popup (нажмите на иконку расширения)
2. Нажмите **F12** (DevTools)
3. Вкладка **Console**
4. Должно быть: `"Skool Token Extractor loaded"`

### 2. Проверить network requests

1. Откройте popup
2. F12 → Вкладка **Network**
3. Обновите popup
4. Должны быть ТОЛЬКО запросы к `skool.com` (cookies)

**Если есть запросы на другие домены** → ❌ Плохо!

### 3. Проверить права

1. `chrome://extensions/`
2. Нажмите на "Details" вашего расширения
3. Раздел "Permissions"
4. Должно быть:
   - `cookies`
   - `activeTab`
   - `https://www.skool.com/*`

---

## 📋 Полный список файлов

Расширение должно содержать:

```
chrome-extension/
├── manifest.json          ✅ Есть
├── popup.html             ✅ Есть
├── popup.js              ✅ ✅ СОЗДАН (исправлено!)
├── icons/
│   ├── icon16.png        ✅ Есть
│   ├── icon48.png        ✅ Есть
│   └── icon128.png       ✅ Есть
└── README.md             ✅ Есть
```

---

## 🎯 Тестирование

### Шаг 1: Установка

1. Откройте `chrome://extensions/`
2. Включите "Developer mode"
3. "Load unpacked"
4. Выберите папку `chrome-extension/`

### Шаг 2: Проверка

1. Зайдите на https://www.skool.com
2. Нажмите на иконку расширения
3. Должен открыться popup

### Шаг 3: Тест

**Кнопка "Refresh Tokens":**
- Показывает User ID
- Показывает даты выдачи/истечения
- Показывает токены

**Кнопка "Copy Tokens":**
- Копирует в clipboard:
  ```
  Client ID: ...
  JWT Token: ...
  ```

**Кнопка "Send to API":**
- Открывает Make.com с предзаполненными полями

---

## ⚠️ Частые ошибки

### Ошибка 1: "No auth_token found"

**Причина:** Не залогинены на Skool

**Решение:**
1. Откройте https://www.skool.com
2. Войдите в аккаунт
3. Обновите popup

---

### Ошибка 2: Popup пустой

**Причина:** Нет popup.js

**Решение:** ✅ УЖЕ ИСПРАВЛЕНО!

---

### Ошибка 3: Кнопки не работают

**Причина:** Нет JavaScript кода

**Решение:** ✅ УЖЕ ИСПРАВЛЕНО!

---

## 🚀 После исправлений

1. **Перезагрузите расширение**
   ```
   chrome://extensions/ → Reload 🔄
   ```

2. **Закройте и откройте popup**
   - Закройте popup
   - Нажмите на иконку расширения снова

3. **Проверьте консоль**
   - F12 → Console
   - Должно быть: "Skool Token Extractor loaded"

---

## 📞 Если всё ещё не работает

### Debug режим:

1. Откройте popup
2. F12 → Console
3. Посмотрите ошибки

### Service Worker:

1. `chrome://extensions/`
2. Нажмите "service worker (Inactive)"
3. Попробуйте нажать "Start"

### Полная переустановка:

1. Удалите расширение
2. Перезагрузите Chrome
3. Установите заново

---

## ✅ Проверить исправление

После добавления `popup.js`:

```bash
# Проверить что файл существует
ls chrome-extension/popup.js
# Должен показать: popup.js

# Проверить права
cat chrome-extension/manifest.json | grep permissions
# Должно быть: "cookies", "activeTab"
```

---

## 🎉 Готово!

Расширение теперь **полностью функционально**! ✅

**Просто перезагрузите расширение:**
```
chrome://extensions/ → Reload 🔄
```
