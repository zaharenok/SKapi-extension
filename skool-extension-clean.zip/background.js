// Background Script v2.5.9 - Messages timeout increased
// Fixed: Messages check timeout 30s → 60s (needed more time for Playwright)
// Fixed: Post-sleep messages timeout 60s → 90s
// Improved: Backend now uses Skool badge count directly for unread (more accurate)
//
// v2.5.8 - Improved post-sleep recovery
// Fixed: Recovery mode now properly persists and is checked on every request
// Fixed: Time-based sleep detection (>30 min) now always sets recovery mode
// Fixed: Added more aggressive retry after sleep (8 attempts vs 3)
// Fixed: Improved error logging with recovery state info
// Fixed: Messages check uses proper recovery mode detection
// Fixed: Recovery state loaded at start of every check to ensure consistency
// Fixed: v2.5.7 - Removed markAllReadBtn button and event handler causing null error
// Fixed: v2.5.7 - Increased startup delay 30s → 60s for cold start network stabilization
// Fixed: v2.5.7 - Increased post-sleep delays 20s/40s/60s → 30s/60s/90s
// Fixed: v2.5.7 - Fixed [object Object] logging - now serializes as JSON
// Fixed: v2.5.7 - Increased health check retries 3 → 5 after long sleep
// Fixed: v2.5.7 - Increased health check timeout 15s → 30s after sleep
// Fixed: v2.5.7 - Replaced Promise.race with AbortController for proper timeout handling

// ============================================================================
// OFFICIAL CHROME EXTENSION SERVICE WORKER PATTERNS (per Chrome Dev docs)
// ============================================================================
// 1. Service workers can terminate at ANY time - persist ALL state to chrome.storage
// 2. Workers run as long as actively receiving events, then may shut down
// 3. No DOM access - use content scripts for window events
// 4. Use chrome.alarms for ALL scheduling that must survive worker restarts
// ============================================================================

// State - strictly for in-memory caching during active session
// ALL persistent state is loaded/saved from chrome.storage
let state = {
  notificationCount: 0,
  messagesCount: 0,
  messagesCountUnread: 0,
  joinRequestCount: 0,
  lastCheckTime: 0,
  recentNotifications: [],
  recentMessages: []
};

let settings = {
  notificationsEnabled: true,
  desktopNotificationsEnabled: true,
  joinRequestsEnabled: false,
  messagesEnabled: false,
  checkInterval: 5,
  badgeMode: 'all',  // 'all', 'notifications', 'messages'
  communitySlug: '',
  filters: {
    type: null,
    author: null,
    keywords: []
  }
};

// ============================================================================
// ERROR RECOVERY STATE (persisted to storage)
// ============================================================================
// These MUST be persisted because service worker can restart at any time
let recoveryState = {
  consecutiveErrors: 0,
  isOffline: false,
  lastSuccessfulCheck: 0,
  errorBackoffLevel: 0,  // Increases with each error, resets on success
  isInRecoveryMode: false  // Set after sleep, reset on first success
};

const API_URL = 'https://skoolpublikgroupchecker-production.up.railway.app';
const ALARM_NAME = 'notificationCheck';
const KEEP_ALIVE_ALARM = 'keepAlive';
const RETRY_ALARM_PREFIX = 'retry_';
const MIN_CHECK_INTERVAL = 60000; // Minimum 1 minute between checks
const MAX_RETRY_ATTEMPTS = 3;
const RETRY_DELAYS = [2000, 5000, 10000]; // Exponential backoff: 2s, 5s, 10s
const KEEP_ALIVE_INTERVAL = 0.5; // Check every 30 seconds

// Error recovery constants
const MAX_CONSECUTIVE_ERRORS = 10; // Give up after 10 consecutive errors (was 5)
const ERROR_BACKOFF_LEVELS = [0, 5000, 15000, 30000, 60000]; // 0s, 5s, 15s, 30s, 60s
const RECOVERY_MODE_COOLDOWN = 30000; // Wait 30s before aggressive retries after sleep

// Health check timeouts
const HEALTH_CHECK_TIMEOUT_NORMAL = 5000; // 5 seconds for normal checks
const HEALTH_CHECK_TIMEOUT_POST_SLEEP = 30000; // 30 seconds after sleep (network needs more time)

// Initialize
chrome.runtime.onInstalled.addListener(() => {
  console.log('🚀 SKapi.pro v2.5.9 installed - Messages timeout increased');
  initialize();
});

chrome.runtime.onStartup.addListener(async () => {
  console.log('💻 SKapi.pro v2.5.8 - browser starting up');

  // Load state first to check if we're recovering from sleep
  await loadRecoveryState();
  await loadState();

  // Check if we're waking from long sleep (browser was closed)
  const timeSinceLastCheck = Date.now() - (state.lastCheckTime || 0);
  const isLongSleep = timeSinceLastCheck > 1800000; // 30 minutes

  if (isLongSleep) {
    console.log('💤 Detected long sleep on startup (>30 min)');
    recoveryState.isInRecoveryMode = true;
    await saveRecoveryState();
  }

  initialize();

  // Delay check more after browser startup for network stabilization
  // Increased from 30s to 60s - network needs more time after cold start
  console.log('🌐 Scheduling startup check in 60s for network stabilization');
  setTimeout(() => {
    console.log('🔄 Executing startup notification check...');
    checkNotificationsViaAPI();
  }, 60000);
});

// Detect when computer wakes from sleep
chrome.idle.onStateChanged.addListener(async (newState) => {
  if (newState === 'active' || newState === 'idle') {
    console.log('💤 Computer woke up from sleep - state:', newState);

    // Load recovery state from storage (it may have been reset if worker restarted)
    await loadRecoveryState();

    // Reset error counters - network is reconnecting
    resetErrorCounters();

    // Enter recovery mode - be more aggressive about retries
    recoveryState.isInRecoveryMode = true;
    await saveRecoveryState();

    console.log('🔧 Entered recovery mode after sleep');

    // Force immediate check with longer delay for network
    initialize();

    // Staggered follow-up checks for network stabilization using chrome.alarms
    // These will survive service worker restarts
    // Increased delays for better network stabilization after sleep
    // Network can take up to 90 seconds to fully stabilize after wake-up
    const delays = [30000, 60000, 90000]; // 30s, 60s, 90s (was 20s, 40s, 60s)
    delays.forEach((delay, i) => {
      const alarmName = `postsleep_${Date.now()}_${i}`;

      // For short delays (< 1 min), we use setTimeout but the alarm system handles retries
      if (delay < 60000) {
        setTimeout(() => {
          console.log(`🔄 Post-sleep follow-up check ${i + 1}/${delays.length}...`);
          checkNotificationsViaAPI();
        }, delay);
      } else {
        chrome.alarms.create(alarmName, {
          delayInMinutes: Math.ceil(delay / 60000)
        });
      }
    });
  }
});

// Listen for network state messages from content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'NETWORK_ONLINE') {
    (async () => {
      await loadRecoveryState();
      if (recoveryState.isOffline) {
        console.log('🌐 Network is back online - resetting error state');
        recoveryState.isOffline = false;
        resetErrorCounters();
        await saveRecoveryState();
        checkNotificationsViaAPI();
      }
    })();
  } else if (request.type === 'NETWORK_OFFLINE') {
    console.log('📡 Network is offline');
    recoveryState.isOffline = true;
    saveRecoveryState();
  }
  // ... other message handlers are below
});

// Keep service worker alive when popup opens
chrome.runtime.onConnect.addListener((port) => {
  console.log('🔌 Popup connected, keeping service worker alive');

  port.postMessage({ type: 'KEEP_ALIVE', timestamp: Date.now() });

  const pingInterval = setInterval(() => {
    try {
      port.postMessage({ type: 'KEEP_ALIVE', timestamp: Date.now() });
    } catch (e) {
      clearInterval(pingInterval);
    }
  }, 20000);

  port.onDisconnect.addListener(() => {
    console.log('🔌 Popup disconnected');
    clearInterval(pingInterval);
  });
});

// ============================================================================
// STATE MANAGEMENT (PERSISTED TO STORAGE)
// ============================================================================

async function initialize() {
  await loadSettings();
  await loadState();
  await loadRecoveryState(); // Load error recovery state

  // Clean up any stale retry alarms from previous session
  await clearRetryAlarms();

  setupKeepAliveAlarm();
  setupPeriodicCheck();

  console.log('📊 Current recovery state:', {
    consecutiveErrors: recoveryState.consecutiveErrors,
    isOffline: recoveryState.isOffline,
    errorBackoffLevel: recoveryState.errorBackoffLevel,
    isInRecoveryMode: recoveryState.isInRecoveryMode
  });
}

// Load settings from storage
async function loadSettings() {
  const result = await chrome.storage.local.get(['settings']);
  if (result.settings) {
    settings = {
      ...settings,
      ...result.settings
    };
    if (settings.messagesEnabled === undefined) {
      settings.messagesEnabled = false;
    }
  }
}

// Load state from storage
async function loadState() {
  const result = await chrome.storage.local.get(['state', 'recentNotifications', 'recentMessages']);
  if (result.recentNotifications) {
    state.recentNotifications = result.recentNotifications;
    console.log('📂 Loaded', result.recentNotifications.length, 'notifications from storage');
  }
  if (result.recentMessages) {
    state.recentMessages = result.recentMessages;
    console.log('📂 Loaded', result.recentMessages.length, 'messages from storage');
  }

  if (result.state) {
    state = {
      ...state,
      notificationCount: result.state.notificationCount || 0,
      messagesCount: result.state.messagesCount || 0,
      messagesCountUnread: result.state.messagesCountUnread || 0,
      joinRequestCount: result.state.joinRequestCount || 0,
      lastCheckTime: result.state.lastCheckTime || 0
    };

    // Recalculate counts from actual lists ONLY if lists exist
    // If lists are empty, trust the stored counts (they might be cleared but counts still valid)
    if (state.recentNotifications.length > 0) {
      const actualUnreadCount = state.recentNotifications.filter(n => n.is_unread).length;
      if (actualUnreadCount !== state.notificationCount) {
        console.log('🧹 Recalculating notificationCount from list:', {
          stored: state.notificationCount,
          actual: actualUnreadCount
        });
        state.notificationCount = actualUnreadCount;
      }
    } else {
      // No notifications list - keep stored count or use 0
      console.log('📭 No notifications list stored, using count from state:', state.notificationCount);
    }

    if (state.recentMessages.length > 0) {
      const actualMessagesUnread = state.recentMessages.filter(m => m.is_unread).length;
      if (actualMessagesUnread !== state.messagesCountUnread) {
        console.log('🧹 Recalculating messagesCountUnread from list:', {
          stored: state.messagesCountUnread,
          actual: actualMessagesUnread
        });
        state.messagesCountUnread = actualMessagesUnread;
      }
    } else {
      // No messages list - keep stored count or use 0
      console.log('📭 No messages list stored, using count from state:', state.messagesCountUnread);
    }

    const totalBadgeCount = (state.notificationCount || 0) + (state.messagesCountUnread || 0);

    console.log('📂 State loaded from storage:', {
      notificationCount: state.notificationCount,
      messagesCount: state.messagesCount,
      messagesCountUnread: state.messagesCountUnread,
      totalBadge: totalBadgeCount,
      joinRequestCount: state.joinRequestCount,
      lastCheckTime: state.lastCheckTime
    });

    // Refresh badge with all current data (not just notifications)
    refreshBadge();
  }
}

// Save state to storage
async function saveState() {
  await chrome.storage.local.set({
    state: {
      notificationCount: state.notificationCount,
      messagesCount: state.messagesCount,
      messagesCountUnread: state.messagesCountUnread,
      joinRequestCount: state.joinRequestCount,
      lastCheckTime: state.lastCheckTime
    },
    recentNotifications: state.recentNotifications,
    recentMessages: state.recentMessages
  });
}

// ============================================================================
// ERROR RECOVERY STATE MANAGEMENT
// ============================================================================

async function loadRecoveryState() {
  const result = await chrome.storage.local.get(['recoveryState']);
  if (result.recoveryState) {
    recoveryState = {
      ...recoveryState,
      ...result.recoveryState
    };
    console.log('🔧 Recovery state loaded:', recoveryState);
  }
}

async function saveRecoveryState() {
  await chrome.storage.local.set({ recoveryState });
}

function resetErrorCounters() {
  recoveryState.consecutiveErrors = 0;
  recoveryState.errorBackoffLevel = 0;
  recoveryState.isOffline = false;
  console.log('🔄 Error counters reset');
}

async function incrementErrorCount() {
  recoveryState.consecutiveErrors++;

  // Increase backoff level with each error (up to max)
  if (recoveryState.errorBackoffLevel < ERROR_BACKOFF_LEVELS.length - 1) {
    recoveryState.errorBackoffLevel++;
  }

  console.log(`⚠️ Error count: ${recoveryState.consecutiveErrors}, backoff level: ${recoveryState.errorBackoffLevel}`);

  // Check if we should give up temporarily
  if (recoveryState.consecutiveErrors >= MAX_CONSECUTIVE_ERRORS && !recoveryState.isOffline) {
    console.log(`📡 ${MAX_CONSECUTIVE_ERRORS}+ consecutive errors - entering offline mode`);
    recoveryState.isOffline = true;
  }

  await saveRecoveryState();

  // Return the backoff delay for this error level
  return ERROR_BACKOFF_LEVELS[recoveryState.errorBackoffLevel] || ERROR_BACKOFF_LEVELS[ERROR_BACKOFF_LEVELS.length - 1];
}

// ============================================================================
// ALARM MANAGEMENT
// ============================================================================

function setupKeepAliveAlarm() {
  chrome.alarms.create(KEEP_ALIVE_ALARM, {
    periodInMinutes: KEEP_ALIVE_INTERVAL
  });
  console.log(`💓 Keep-alive alarm set every ${KEEP_ALIVE_INTERVAL} minute(s)`);
}

function setupPeriodicCheck() {
  chrome.alarms.clear(ALARM_NAME);

  if (settings.notificationsEnabled) {
    const intervalMinutes = settings.checkInterval || 5;
    chrome.alarms.create(ALARM_NAME, {
      periodInMinutes: intervalMinutes
    });
    console.log(`🔔 Notification check scheduled every ${intervalMinutes} minutes`);
  }
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === KEEP_ALIVE_ALARM) {
    console.log('💓 Keep-alive ping - service worker is active');
  } else if (alarm.name === ALARM_NAME) {
    console.log('⏰ Alarm triggered - calling checkNotificationsViaAPI...');
    console.log('⏰ Current settings:', { notificationsEnabled: settings.notificationsEnabled, checkInterval: settings.checkInterval });
    checkNotificationsViaAPI();
  } else if (alarm.name.startsWith(RETRY_ALARM_PREFIX)) {
    // Retry alarm - extract the delay info from the alarm name
    console.log('🔄 Retry alarm triggered:', alarm.name);
    checkNotificationsViaAPI();
    // Clear the retry alarm after it fires
    chrome.alarms.clear(alarm.name);
  } else if (alarm.name.startsWith('postsleep_')) {
    // Post-sleep follow-up check
    console.log('🔄 Post-sleep follow-up alarm triggered:', alarm.name);
    checkNotificationsViaAPI();
    chrome.alarms.clear(alarm.name);
  }
});

// ============================================================================
// SCHEDULING HELPERS (Using chrome.alarms for persistence)
// ============================================================================

/**
 * Schedule a retry using chrome.alarms instead of setTimeout.
 * This survives service worker restarts.
 */
function scheduleRetryWithAlarm(delayMs, reason = 'retry') {
  const alarmName = `${RETRY_ALARM_PREFIX}${Date.now()}_${reason}`;

  // Convert to minutes for chrome.alarms (minimum 1 minute = 60000ms)
  // For delays less than 1 minute, we must use setTimeout but accept it may be lost
  if (delayMs < 60000) {
    console.log(`⏰ Scheduling retry in ${delayMs}ms via setTimeout (may be lost if worker restarts)`);
    setTimeout(() => {
      console.log(`🔄 Executing scheduled retry (${reason})`);
      checkNotificationsViaAPI();
    }, delayMs);
  } else {
    // Use chrome.alarms for longer delays (survives worker restart)
    const delayInMinutes = Math.ceil(delayMs / 60000);
    console.log(`⏰ Scheduling retry in ${delayInMinutes} minute(s) via chrome.alarms (${reason})`);

    chrome.alarms.create(alarmName, {
      delayInMinutes: delayInMinutes
    });
  }

  return alarmName;
}

/**
 * Clear all pending retry alarms
 */
async function clearRetryAlarms() {
  const alarms = await chrome.alarms.getAll();
  for (const alarm of alarms) {
    if (alarm.name.startsWith(RETRY_ALARM_PREFIX)) {
      chrome.alarms.clear(alarm.name);
    }
  }
  console.log('🧹 Cleared all retry alarms');
}

// ============================================================================
// API HEALTH CHECK
// ============================================================================

async function checkApiHealth(retries = 2, isPostSleep = false) {
  const timeout = isPostSleep ? HEALTH_CHECK_TIMEOUT_POST_SLEEP : HEALTH_CHECK_TIMEOUT_NORMAL;

  for (let i = 0; i < retries; i++) {
    try {
      console.log(`🏥 Checking API health... (attempt ${i + 1}/${retries}, timeout: ${timeout}ms)`);
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeout);

      const response = await fetch(`${API_URL}/health`, {
        method: 'GET',
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (response.ok) {
        const data = await response.json();
        console.log(`✅ API health check passed:`, data);
        return true;
      }
    } catch (error) {
      const errorDetails = {
        name: error.name,
        message: error.message,
        isTimeout: error.name === 'AbortError'
      };
      console.warn(`⚠️ Health check failed (attempt ${i + 1}/${retries}):`, errorDetails);

      if (i < retries - 1) {
        const delay = isPostSleep ? 5000 : 2000; // Longer delay after sleep (5s vs 3s)
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
  }

  console.error('❌ API health check failed after', retries, 'attempts');
  return false;
}

// ============================================================================
// FETCH WITH RETRY (ENHANCED FOR POST-SLEEP RECOVERY)
// ============================================================================

async function fetchWithRetry(url, options, attempt = 0, isPostSleep = false) {
  try {
    const response = await fetch(url, options);

    // Don't retry on rate limiting (429) or client errors (4xx)
    if (response.status === 429 || (response.status >= 400 && response.status < 500)) {
      return response;
    }

    // More retries after sleep or in recovery mode
    const maxAttempts = (isPostSleep || recoveryState.isInRecoveryMode) ? 8 : MAX_RETRY_ATTEMPTS;
    const delays = isPostSleep || recoveryState.isInRecoveryMode
      ? [3000, 5000, 10000, 15000, 20000, 30000, 45000, 60000]
      : RETRY_DELAYS;

    if (!response.ok && attempt < maxAttempts) {
      const delay = delays[attempt] || delays[delays.length - 1];
      console.log(`⚠️ API error ${response.status}, retrying in ${delay}ms (${attempt + 1}/${maxAttempts})`);
      await new Promise(resolve => setTimeout(resolve, delay));
      return fetchWithRetry(url, options, attempt + 1, isPostSleep);
    }

    return response;
  } catch (error) {
    // Don't retry on AbortError (intentional timeout)
    if (error.name === 'AbortError') {
      throw error;  // Re-throw to let caller handle
    }

    const maxAttempts = (isPostSleep || recoveryState.isInRecoveryMode) ? 8 : MAX_RETRY_ATTEMPTS;
    const delays = isPostSleep || recoveryState.isInRecoveryMode
      ? [3000, 5000, 10000, 15000, 20000, 30000, 45000, 60000]
      : RETRY_DELAYS;

    // Properly log error details - serialize object for better console output
    const errorDetails = {
      name: error.name,
      message: error.message,
      attempt: attempt + 1,
      maxAttempts: maxAttempts,
      isPostSleep: isPostSleep,
      isInRecoveryMode: recoveryState.isInRecoveryMode,
      url: url?.substring(0, 50) + '...'
    };
    console.error(`🔍 Network error:`, JSON.stringify(errorDetails));

    if (attempt < maxAttempts && error.name === 'TypeError') {
      const delay = delays[attempt] || delays[delays.length - 1];
      console.log(`⚠️ Network error (retry ${attempt + 1}/${maxAttempts}), retrying in ${delay}ms...`);
      await new Promise(resolve => setTimeout(resolve, delay));
      return fetchWithRetry(url, options, attempt + 1, isPostSleep);
    }
    throw error;
  }
}

// ============================================================================
// MAIN NOTIFICATION CHECK (WITH ERROR RECOVERY)
// ============================================================================

async function checkNotificationsViaAPI() {
  console.log('🔍 checkNotificationsViaAPI() called');

  if (!settings.notificationsEnabled) {
    console.log('⚠️ Notifications disabled in settings, skipping');
    return;
  }

  // Skip if offline (but check if we should try again)
  if (recoveryState.isOffline) {
    // Check if enough time has passed to retry
    const backoffDelay = ERROR_BACKOFF_LEVELS[recoveryState.errorBackoffLevel];
    const timeSinceLastError = Date.now() - recoveryState.lastSuccessfulCheck;

    if (timeSinceLastError < backoffDelay) {
      console.log(`⏸️ Offline mode - waiting ${Math.ceil((backoffDelay - timeSinceLastError) / 1000)}s before retry`);
      return;
    }

    console.log('🔄 Exiting offline mode - attempting retry');
    recoveryState.isOffline = false;
    await saveRecoveryState();
  }

  await loadState();

  const now = Date.now();
  const timeSinceLastCheck = now - state.lastCheckTime;
  const isLongSleep = timeSinceLastCheck > 1800000; // 30 minutes

  console.log('⏱️ Timing check:', {
    now,
    lastCheckTime: state.lastCheckTime,
    timeSinceLastCheck: Math.floor(timeSinceLastCheck / 1000) + 's',
    isLongSleep,
    MIN_CHECK_INTERVAL: MIN_CHECK_INTERVAL + 'ms'
  });

  if (!isLongSleep && timeSinceLastCheck < MIN_CHECK_INTERVAL) {
    const timeUntilNextCheck = Math.ceil((MIN_CHECK_INTERVAL - timeSinceLastCheck) / 1000);
    console.log(`⏳ Skipping check, ${timeUntilNextCheck}s until next allowed check`);
    return;
  }

  if (isLongSleep) {
    console.log('💤 Detected long sleep period (>30 min)');

    // Enter recovery mode on long sleep
    recoveryState.isInRecoveryMode = true;
    await saveRecoveryState();

    // Health check first with longer timeout after sleep
    console.log('🏥 Running API health check (post-sleep)...');
    const isHealthy = await checkApiHealth(5, true); // 5 retries after sleep (was 3)
    if (!isHealthy) {
      console.error('❌ API health check failed after sleep');

      const backoffDelay = await incrementErrorCount();
      console.log(`⏸️ Backing off for ${backoffDelay}ms`);

      // Use chrome.alarms for retry (survives worker restart)
      scheduleRetryWithAlarm(backoffDelay, 'health_check_failed');

      return;
    }
    console.log('✅ API is healthy - proceeding');
  }

  console.log('🔑 Getting JWT token...');
  let jwtToken = null;

  try {
    jwtToken = await getJwtToken();
    console.log('🔑 JWT token obtained:', jwtToken ? 'YES' : 'NO');

    if (!jwtToken) {
      console.log('⚠️ No JWT token found');
      return;
    }

    // IMPORTANT: Don't update lastCheckTime until API succeeds!
    // This ensures retries after sleep still use isPostSleep=true
    console.log('📤 Starting fetch to /check-notifications...');

    const response = await fetchWithRetry(`${API_URL}/check-notifications`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        jwt_token: jwtToken,
        limit: 99,
        source: 'extension'
      })
    }, 0, isLongSleep || recoveryState.isInRecoveryMode); // Use recovery mode if set

    if (response.status === 429) {
      console.warn('⚠️ Rate limit exceeded');
      return;
    }

    if (!response.ok) {
      console.error('❌ API request failed:', response.status);

      const backoffDelay = await incrementErrorCount();
      scheduleRetryWithAlarm(backoffDelay, 'api_error');
      return;
    }

    const data = await response.json();

    // Handle success:false responses
    if (!data.success) {
      const errorMsg = data.message || data.error || 'Unknown error';
      console.error('⚠️ API returned success:false - Message:', errorMsg);
      console.error('⚠️ Full response:', JSON.stringify(data));

      // Treat success:false as an error - increment counter and retry
      const backoffDelay = await incrementErrorCount();
      console.error(`⚠️ API error, retrying in ${backoffDelay}ms...`);

      scheduleRetryWithAlarm(backoffDelay, 'api_success_false');
      return;
    }

    // Success path - reset error counters
    const notificationsList = data.notifications || [];

    // SUCCESS: Reset all error counters
    await resetErrorCounters();
    recoveryState.lastSuccessfulCheck = now;
    recoveryState.isInRecoveryMode = false; // Exit recovery mode
    await saveRecoveryState();

    console.log('✅ Notification check successful - error counters reset');

    // NOW update lastCheckTime (only on success)
    state.lastCheckTime = now;
    state.recentNotifications = notificationsList;

    await chrome.storage.local.set({
      recentNotifications: notificationsList,
      lastUpdated: Date.now(),
      lastCheckTime: now
    });

    const actualUnreadCount = notificationsList.filter(n => n.is_unread).length;
    console.log(`📬 Unread count: ${actualUnreadCount}`);

    const previousCount = state.notificationCount || 0;

    updateNotificationBadge(actualUnreadCount);
    state.notificationCount = actualUnreadCount;

    if (settings.desktopNotificationsEnabled && actualUnreadCount > 0 && actualUnreadCount > previousCount) {
      const newCount = actualUnreadCount - previousCount;
      const urlToOpen = notificationsList.length > 0
        ? notificationsList[0].url
        : 'https://skool.com/notifications';

      showDesktopNotification(
        'SKapi.pro',
        `You have ${newCount} new notification${newCount > 1 ? 's' : ''} on Skool`,
        'notification',
        { url: urlToOpen }
      );
    }

    chrome.runtime.sendMessage({
      type: 'NOTIFICATIONS_UPDATED',
      count: actualUnreadCount,
      notifications: notificationsList
    }, () => {
      if (chrome.runtime.lastError) { /* Popup closed */ }
    });

    await saveState();

    // Check join requests if enabled
    if (settings.joinRequestsEnabled && settings.communitySlug && jwtToken) {
      await checkJoinRequestsViaAPI(jwtToken, isLongSleep);
    }

    // Check messages if enabled
    if (settings.messagesEnabled && jwtToken) {
      await checkMessagesViaAPI(jwtToken, isLongSleep);
    }

  } catch (error) {
    console.error('❌ Error checking notifications:', error.message);

    const backoffDelay = await incrementErrorCount();

    // Only log detailed error info periodically to reduce spam
    if (recoveryState.consecutiveErrors <= 2 ||
        recoveryState.consecutiveErrors % 5 === 1) {
      console.error(`📊 Error summary (${recoveryState.consecutiveErrors} consecutive):`, JSON.stringify({
        message: error.message,
        name: error.name,
        isOffline: recoveryState.isOffline,
        backoffLevel: recoveryState.errorBackoffLevel,
        nextRetryIn: `${backoffDelay}ms`
      }));
    }

    // Schedule retry with exponential backoff using chrome.alarms
    scheduleRetryWithAlarm(backoffDelay, 'catch_error');
  }
}

// ============================================================================
// MESSAGES CHECK
// ============================================================================

async function checkMessagesViaAPI(jwtToken, isPostSleep = false) {
  if (!jwtToken) {
    console.warn('⚠️ No JWT token for messages check');
    return;
  }

  const startTime = Date.now();
  console.log('💬 Checking messages...');

  // Health check first for post-sleep (API might not be ready yet)
  if (isPostSleep) {
    console.log('🏥 Running API health check before messages...');
    const isHealthy = await checkApiHealth(1, true);
    if (!isHealthy) {
      console.warn('⚠️ API health check failed - skipping messages check');
      return;
    }
  }

  try {
    // Use AbortController for proper timeout (Promise.race doesn't work in service workers)
    const timeout = isPostSleep ? 90000 : 60000; // 90s after sleep, 60s normally (messages need more time)
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeout);

    // Keep service worker alive during long fetch (call an API every 20s)
    const keepAliveInterval = setInterval(() => {
      chrome.storage.local.get('keep-alive-tick', () => {
        // Trivial API call to reset service worker timeout
      });
    }, 20000);

    try {
      const response = await fetchWithRetry(`${API_URL}/check-messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jwt_token: jwtToken,
          limit: 99,
          source: 'extension'
        }),
        signal: controller.signal  // AbortController signal
      }, 0, isPostSleep);

      clearTimeout(timeoutId);
      clearInterval(keepAliveInterval);

      console.log(`📬 Messages API response: ${response.status} (${Date.now() - startTime}ms)`);

      if (response.status === 429) {
        console.warn('⚠️ Rate limit exceeded for messages');
        return;
      }

      if (!response.ok) {
        console.log('⚠️ Messages API failed:', response.status);
        return;
      }

      const data = await response.json();
      console.log('📦 Messages API data:', { success: data.success, count: data.count, unread: data.unread_count });

      if (!data.success) {
        const errorMsg = data.message || data.error || 'Unknown error';
        console.warn('⚠️ Messages API returned success:false - Message:', errorMsg);
        return;
      }

      const unreadCount = data.unread_count || 0;
      const messagesList = data.messages || [];

      state.recentMessages = messagesList;
      state.messagesCount = unreadCount;

      await chrome.storage.local.set({ recentMessages: messagesList });

      const messagesCountUnread = messagesList.filter(msg => msg.is_unread).length;
      state.messagesCountUnread = messagesCountUnread;

      console.log(`✅ Messages: ${unreadCount} unread, ${messagesList.length} total`);

      // Refresh badge with both notifications and messages
      refreshBadge();

      chrome.runtime.sendMessage({
        type: 'MESSAGES_UPDATED',
        count: unreadCount,
        messagesCountUnread: messagesCountUnread,
        messages: messagesList
      }, () => {
        if (chrome.runtime.lastError) { /* Popup closed */ }
      });

      await saveState();
    } catch (abortError) {
      if (abortError.name === 'AbortError') {
        console.warn(`⏱️ Messages check timed out after ${timeout}ms (${Date.now() - startTime}ms total)`);
        // Don't increment error counter for timeout - it's not a real error
        return;
      }
      throw abortError;
    } finally {
      clearTimeout(timeoutId);
      clearInterval(keepAliveInterval);
    }

  } catch (error) {
    // Don't log timeouts as errors (already logged above)
    if (error.name !== 'AbortError') {
      console.error('❌ Error checking messages:', error.message, `(${Date.now() - startTime}ms)`);
    }
  }
}

// ============================================================================
// JOIN REQUESTS CHECK
// ============================================================================

async function checkJoinRequestsViaAPI(jwtToken, isPostSleep = false) {
  if (!jwtToken || !settings.communitySlug) return;

  try {
    console.log('📋 Checking join requests for:', settings.communitySlug);

    const cookies = await chrome.cookies.getAll({ domain: '.skool.com' });

    const response = await fetchWithRetry(`${API_URL}/check-join-requests`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        jwt_token: jwtToken,
        group: settings.communitySlug,
        cookies: cookies,
        source: 'extension'
      })
    }, 0, isPostSleep);

    if (response.status === 429) {
      console.warn('⚠️ Rate limit exceeded for join requests');
      return;
    }

    if (!response.ok) {
      console.log('⚠️ Join requests API failed:', response.status);
      return;
    }

    const data = await response.json();

    // Handle success:false responses
    if (data.success === false) {
      const errorMsg = data.message || data.error || 'Unknown error';
      console.warn('⚠️ Join requests API returned success:false - Message:', errorMsg);
      return;
    }

    if (data.join_requests) {
      await chrome.storage.local.set({ joinRequestsData: data.join_requests });

      const countText = data.join_requests.count_text;
      const count = parseInt(countText) || 0;

      console.log(`📋 Found ${count} pending join requests`);

      if (count > 0 && count > state.joinRequestCount) {
        showDesktopNotification(
          'SKapi.pro - Pending Members',
          `You have ${count} pending join request${count > 1 ? 's' : ''}`,
          'notification',
          { url: `https://skool.com/${settings.communitySlug}/membership` }
        );
      }

      state.joinRequestCount = count;

      chrome.runtime.sendMessage({
        type: 'JOIN_REQUESTS_UPDATED',
        count: count,
        data: data.join_requests
      }, () => {
        if (chrome.runtime.lastError) { /* Popup closed */ }
      });
    } else {
      console.log('✅ No pending join requests');
      state.joinRequestCount = 0;
    }

    await saveState();
  } catch (error) {
    console.error('❌ Error checking join requests:', error.message);
  }
}

// ============================================================================
// JWT TOKEN HELPER
// ============================================================================

async function getJwtToken() {
  return new Promise((resolve) => {
    chrome.cookies.getAll({ domain: '.skool.com' }, (cookies) => {
      const authTokenCookie = cookies.find(c => c.name === 'auth_token');
      const token = authTokenCookie ? authTokenCookie.value : null;

      if (token) {
        chrome.storage.local.set({ jwtToken: token });
      }

      resolve(token);
    });
  });
}

// ============================================================================
// BADGE MANAGEMENT
// ============================================================================

// Update badge based on badgeMode setting
function updateNotificationBadge(notificationsCount) {
  state.notificationCount = notificationsCount;

  let badgeCount = 0;

  // Calculate badge count based on badgeMode
  switch (settings.badgeMode) {
    case 'notifications':
      badgeCount = state.notificationCount || 0;
      break;
    case 'messages':
      badgeCount = state.messagesCountUnread || 0;
      break;
    case 'all':
    default:
      badgeCount = (state.notificationCount || 0) + (state.messagesCountUnread || 0);
      break;
  }

  console.log('🔢 Badge update:', {
    mode: settings.badgeMode,
    notifications: state.notificationCount,
    messagesUnread: state.messagesCountUnread,
    badgeCount: badgeCount
  });

  saveState();

  if (badgeCount > 0 && settings.notificationsEnabled) {
    const badgeText = badgeCount > 99 ? '99+' : badgeCount.toString();
    chrome.action.setBadgeText({ text: badgeText });
    chrome.action.setBadgeBackgroundColor({ color: '#FF90E8' });
    chrome.action.setBadgeTextColor({ color: '#0A0A0A' });
  } else {
    chrome.action.setBadgeText({ text: '' });
  }
}

// Force refresh badge with current state (call after messages update)
function refreshBadge() {
  let badgeCount = 0;

  switch (settings.badgeMode) {
    case 'notifications':
      badgeCount = state.notificationCount || 0;
      break;
    case 'messages':
      badgeCount = state.messagesCountUnread || 0;
      break;
    case 'all':
    default:
      badgeCount = (state.notificationCount || 0) + (state.messagesCountUnread || 0);
      break;
  }

  console.log('🔢 refreshBadge called:', {
    badgeCount,
    notificationsEnabled: settings.notificationsEnabled,
    badgeMode: settings.badgeMode,
    notificationCount: state.notificationCount,
    messagesCountUnread: state.messagesCountUnread
  });

  if (badgeCount > 0 && settings.notificationsEnabled) {
    const badgeText = badgeCount > 99 ? '99+' : badgeCount.toString();
    chrome.action.setBadgeText({ text: badgeText });
    chrome.action.setBadgeBackgroundColor({ color: '#FF90E8' });
    chrome.action.setBadgeTextColor({ color: '#0A0A0A' });
  } else {
    console.log('🔢 Badge cleared: badgeCount=' + badgeCount + ', notificationsEnabled=' + settings.notificationsEnabled);
    chrome.action.setBadgeText({ text: '' });
  }
}

function clearNotificationBadge() {
  state.notificationCount = 0;
  saveState();
  chrome.action.setBadgeText({ text: '' });
}

// ============================================================================
// DESKTOP NOTIFICATIONS
// ============================================================================

function showDesktopNotification(title, message, type = 'info', options = {}) {
  if (!settings.desktopNotificationsEnabled) return;

  const notificationId = `${Date.now()}|${options.url || ''}`;

  const notificationOptions = {
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: title,
    message: message,
    priority: type === 'error' ? 2 : 1,
    requireInteraction: type === 'notification'
  };

  if (type === 'notification') {
    notificationOptions.buttons = [
      { title: 'Open' },
      { title: 'Dismiss' }
    ];
  }

  chrome.notifications.create(notificationId, notificationOptions, (createdId) => {
    if (chrome.runtime.lastError) {
      console.error('Error showing notification:', chrome.runtime.lastError);
    }
  });
}

function handleNotificationClick(notificationId) {
  const parts = notificationId.split('|');
  if (parts.length > 1 && parts[1]) {
    const url = parts[1];
    if (url.startsWith('http')) {
      chrome.tabs.create({ url: url });
    }
  }
  chrome.notifications.clear(notificationId);
}

chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
  if (buttonIndex === 0) {
    handleNotificationClick(notificationId);
  } else {
    chrome.notifications.clear(notificationId);
  }
});

chrome.notifications.onClicked.addListener((notificationId) => {
  handleNotificationClick(notificationId);
});

// ============================================================================
// MESSAGE HANDLING
// ============================================================================

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('📨 Background received:', request.type);

  // Any message from popup means extension is active - reset ALL error state
  (async () => {
    await loadRecoveryState();
    const hadErrors = recoveryState.consecutiveErrors > 0 || recoveryState.isOffline;
    if (hadErrors) {
      console.log('🔄 Resetting error state - popup opened');
      resetErrorCounters();
      await saveRecoveryState();
    }
  })();

  // Handle immediate response messages
  if (request.type === 'WAKE_UP_PING') {
    console.log('💓 Wake-up ping received');
    sendResponse({ status: 'alive', timestamp: Date.now() });
    return true;
  }

  // Handle async messages
  switch (request.type) {
    case 'GET_NOTIFICATION_COUNT':
      loadState().then(() => {
        sendResponse({
          count: state.notificationCount || 0,
          messagesCount: state.messagesCount || 0,
          messagesCountUnread: state.messagesCountUnread || 0,
          joinRequestsCount: state.joinRequestCount || 0,
          notifications: state.recentNotifications || [],
          messages: state.recentMessages || []
        });
      }).catch((error) => {
        console.error('❌ Error loading state:', error);
        sendResponse({
          count: state.notificationCount || 0,
          messagesCount: state.messagesCount || 0,
          messagesCountUnread: state.messagesCountUnread || 0,
          joinRequestsCount: state.joinRequestCount || 0,
          notifications: state.recentNotifications || [],
          messages: state.recentMessages || [],
          error: 'Failed to load state'
        });
      });
      return true;

    case 'SET_BADGE':
      updateNotificationBadge(request.count);
      sendResponse({ success: true });
      break;

    case 'CLEAR_BADGE':
      clearNotificationBadge();
      sendResponse({ success: true });
      break;

    case 'UPDATE_SETTINGS':
      settings = { ...settings, ...request.settings };
      setupPeriodicCheck();
      sendResponse({ success: true });
      break;

    case 'GET_COOKIES':
      chrome.cookies.getAll({ domain: '.skool.com' }, (cookies) => {
        const clientIdCookie = cookies.find(c => c.name === 'client_id');
        const authTokenCookie = cookies.find(c => c.name === 'auth_token');
        sendResponse({
          client_id: clientIdCookie ? clientIdCookie.value : null,
          auth_token: authTokenCookie ? authTokenCookie.value : null
        });
      });
      return true;

    case 'CHECK_NOW':
      checkNotificationsViaAPI().then(() => {
        sendResponse({ success: true });
      });
      return true;

    default:
      sendResponse({ error: 'Unknown message type' });
  }

  return true;
});

// ============================================================================
// SETTINGS CHANGE LISTENER
// ============================================================================

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.settings) {
    settings = { ...settings, ...changes.settings.newValue };
    setupPeriodicCheck();
    console.log('⚙️ Settings updated:', settings);
  }
});
