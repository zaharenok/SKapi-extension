// Content Script - Runs on Skool pages
// Monitors network status and communicates with background script

const sendNetworkStatus = (type) => {
  try {
    if (chrome.runtime && chrome.runtime.sendMessage) {
      chrome.runtime.sendMessage({ type });
    }
  } catch (error) {
  }
};

window.addEventListener('online', () => {
  sendNetworkStatus('NETWORK_ONLINE');
});

window.addEventListener('offline', () => {
  sendNetworkStatus('NETWORK_OFFLINE');
});
