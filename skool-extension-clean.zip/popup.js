// SKapi.pro - Popup Script
// Retro Terminal Edition v2.0

document.addEventListener('DOMContentLoaded', function() {
  console.log('💜 SKapi.pro loaded');

  // Elements
  const navTabs = document.querySelectorAll('.nav-tab');
  const pages = document.querySelectorAll('.page');

  // Dashboard elements
  const tokenStatus = document.getElementById('tokenStatus');
  const userId = document.getElementById('userId');
  const jwtToken = document.getElementById('jwtToken');
  const expiryDate = document.getElementById('expiryDate');

  // Dashboard elements
  const serviceStatusDot = document.getElementById('serviceStatusDot');
  const serviceStatusText = document.getElementById('serviceStatusText');

  // Monitor elements
  const unreadCount = document.getElementById('unreadCount');
  const messagesCount = document.getElementById('messagesCount');
  const joinRequestsCount = document.getElementById('joinRequestsCount');
  const joinRequestsDot = document.getElementById('joinRequestsDot');
  const messagesDot = document.getElementById('messagesDot');
  const messagesUnreadBadge = document.getElementById('messagesUnreadBadge');
  const notificationList = document.getElementById('notificationList');
  const messagesList = document.getElementById('messagesList');
  const refreshMonitor = document.getElementById('refreshMonitor');
  const refreshMonitorList = document.getElementById('refreshMonitorList');
  const refreshMessagesList = document.getElementById('refreshMessagesList');

  // Usage Plan elements
  const planName = document.getElementById('planName');
  const monthlyUsed = document.getElementById('monthlyUsed');
  const monthlyQuota = document.getElementById('monthlyQuota');
  const monthlyRemaining = document.getElementById('monthlyRemaining');
  const rateLimitInfo = document.getElementById('rateLimitInfo');
  const refreshUsage = document.getElementById('refreshUsage');

  // Buttons
  const refreshTokens = document.getElementById('refreshTokens');
  const copyTokens = document.getElementById('copyTokens');
  const visitSite = document.getElementById('visitSite');

  // Settings elements
  const notificationsToggle = document.getElementById('notificationsToggle');
  const desktopToggle = document.getElementById('desktopToggle');
  const joinRequestsToggle = document.getElementById('joinRequestsToggle');
  const messagesToggle = document.getElementById('messagesToggle');
  const checkInterval = document.getElementById('checkInterval');
  const communitySlug = document.getElementById('communitySlug');
  const lockCommunity = document.getElementById('lockCommunity');
  const communityStatus = document.getElementById('communityStatus');
  const lockStatus = document.getElementById('lockStatus');
  const saveSettings = document.getElementById('saveSettings');
  const saveCommunity = document.getElementById('saveCommunity');

  // State
  let currentSettings = {
    notificationsEnabled: true,
    desktopNotificationsEnabled: true,
    joinRequestsEnabled: false,
    messagesEnabled: false,
    checkInterval: 5,
    badgeMode: 'all',  // 'all', 'notifications', 'messages'
    communitySlug: '',
    communitySlugLocked: false,  // Lock to prevent auto-detection
    filters: {
      type: null,
      author: null,
      keywords: []
    }
  };

  // Saved stats persistence
  let savedStats = {
    unreadCount: null,
    messagesCount: null,
    joinRequestsCount: null,
    lastUpdated: null
  };

  // Token storage for click-to-reveal
  let fullUserId = '';
  let fullJwtToken = '';

  // Initialize
  init();

  async function init() {
    await loadSettings();  // FIXED: Now properly awaits settings load
    setupNavigation();
    setupEventListeners();
    await autoDetectCommunitySlug();
    await extractTokens();
    updateServiceStatus();
    await fetchUsagePlan(); // Fetch plan info on init

    // Get fresh data from background on init (not from storage)
    await fetchFreshStatsFromBackground();

    // Auto-refresh usage plan every 30 seconds
    setInterval(fetchUsagePlan, 30000);
  }

  // Navigation
  function setupNavigation() {
    navTabs.forEach(tab => {
      tab.addEventListener('click', () => {
        const pageName = tab.dataset.page;
        switchPage(pageName);
      });
    });
  }

  function switchPage(pageName) {
    // Update tabs
    navTabs.forEach(tab => {
      if (tab.dataset.page === pageName) {
        tab.classList.add('active');
      } else {
        tab.classList.remove('active');
      }
    });

    // Update pages
    pages.forEach(page => {
      if (page.id === `${pageName}Page`) {
        page.classList.add('active');
      } else {
        page.classList.remove('active');
      }
    });

    // Fetch fresh data from background when switching to Monitor or Dashboard page
    if (pageName === 'monitor' || pageName === 'dashboard') {
      fetchFreshStatsFromBackground();
      loadCachedData(); // Load cached notifications and requests
    }
  }

  // Fetch fresh stats from background (always use live data, not cached storage)
  async function fetchFreshStatsFromBackground() {
    // Show waking up state initially
    unreadCount.textContent = 'waking up...';
    messagesCount.textContent = 'waking up...';
    joinRequestsCount.textContent = 'waking up...';

    // Check if chrome.runtime is available (extension context)
    if (!chrome || !chrome.runtime) {
      console.error('❌ chrome.runtime not available - not running in extension context');
      unreadCount.textContent = 'error';
      messagesCount.textContent = 'error';
      joinRequestsCount.textContent = 'error';
      return;
    }

    // Check for post-sleep condition
    chrome.storage.local.get(['lastCheckTime'], (result) => {
      const lastCheck = result.lastCheckTime || 0;
      const timeSinceLastCheck = Date.now() - lastCheck;
      const isPostSleep = timeSinceLastCheck > 3600000; // 1 hour
      
      if (isPostSleep) {
        console.log('💤 Detected post-sleep wake-up, giving background extra time...');
      }

      // Try to get stats with retry logic
      tryGetStatsWithRetry(0, isPostSleep);
    });
  }

  // Try to get stats from background with retry logic
  function tryGetStatsWithRetry(attempt, isPostSleep = false) {
    const maxAttempts = isPostSleep ? 8 : 5; // More retries after sleep
    const baseDelay = isPostSleep ? 2000 : 1000; // Longer delays after sleep

    if (attempt >= maxAttempts) {
      console.error('❌ Max retry attempts reached, giving up');
      unreadCount.textContent = 'inactive';
      messagesCount.textContent = 'inactive';
      joinRequestsCount.textContent = 'inactive';
      return;
    }

    // Check if chrome.runtime.sendMessage is available
    if (!chrome.runtime || !chrome.runtime.sendMessage) {
      console.warn(`⏳ chrome.runtime not ready, attempt ${attempt + 1}/${maxAttempts}`);
      
      setTimeout(() => {
        tryGetStatsWithRetry(attempt + 1, isPostSleep);
      }, baseDelay * (attempt + 1)); // Exponential backoff
      
      return;
    }

    // Set timeout for this attempt
    const timeoutMs = isPostSleep ? 25000 : 15000; // Longer timeout after sleep
    const timeoutId = setTimeout(() => {
      console.warn(`⏰ Background timeout on attempt ${attempt + 1}/${maxAttempts}, retrying...`);
      tryGetStatsWithRetry(attempt + 1, isPostSleep);
    }, timeoutMs);

    // Send wake-up ping first to ensure service worker is running
    chrome.runtime.sendMessage({ type: 'WAKE_UP_PING' }, (pingResponse) => {
      clearTimeout(timeoutId);
      
      console.log('💓 Wake-up ping response:', pingResponse);

      // Now send the actual request
      chrome.runtime.sendMessage({ type: 'GET_NOTIFICATION_COUNT' }, (response) => {
        clearTimeout(timeoutId);

        if (chrome.runtime.lastError) {
          console.error('❌ Error getting stats from background:', chrome.runtime.lastError.message);
          
          // Retry on error
          setTimeout(() => {
            tryGetStatsWithRetry(attempt + 1, isPostSleep);
          }, baseDelay * (attempt + 1));
          return;
        }

        if (!response) {
          console.warn('⚠️ No response from background, retrying...');
           
          setTimeout(() => {
            tryGetStatsWithRetry(attempt + 1, isPostSleep);
          }, baseDelay * (attempt + 1));
          return;
        }

        if (response.error) {
          console.error('❌ Background returned error:', response.error);
          
          setTimeout(() => {
            tryGetStatsWithRetry(attempt + 1, isPostSleep);
          }, baseDelay * (attempt + 1));
          return;
        }

        // Success! Update UI
        console.log('✅ Stats received from background');

        if (response.count !== undefined) {
          unreadCount.textContent = response.count;
          savedStats.unreadCount = response.count;
        }
        if (response.messagesCount !== undefined) {
          messagesCount.textContent = response.messagesCount;
          savedStats.messagesCount = response.messagesCount;
        }
        if (response.messagesCountUnread !== undefined) {
          messagesUnreadBadge.textContent = response.messagesCountUnread;
          if (response.messagesCountUnread > 0) {
            messagesUnreadBadge.style.display = 'inline-block';
          } else {
            messagesUnreadBadge.style.display = 'none';
          }
          savedStats.messagesCountUnread = response.messagesCountUnread;
        }
        if (response.joinRequestsCount !== undefined) {
          joinRequestsCount.textContent = response.joinRequestsCount;
          savedStats.joinRequestsCount = response.joinRequestsCount;
        }
        // Render notifications from background cache (no API call)
        if (response.notifications) {
          renderNotifications(response.notifications, false);
        }
        // Render messages from background cache (no API call)
        if (response.messages) {
          renderMessages(response.messages, false);
        }
        // Save to storage for persistence across sessions
        saveStatsToStorage();

        // Update lastCheckTime to help detect future sleep periods
        chrome.storage.local.set({ lastCheckTime: Date.now() });
      });
    });
  }

  // Load cached notifications and join requests data
  function loadCachedData() {
    // Data is now fetched from background in fetchFreshStatsFromBackground()
    // No need to load from storage - eliminates delay
    if (!chrome || !chrome.storage) {
      console.error('❌ chrome.storage not available');
      return;
    }
    
    chrome.storage.local.get(['joinRequestsData'], (result) => {
      if (result.joinRequestsData) {
        updateJoinRequestsUIFromData(result.joinRequestsData);
      }
    });
  }

  // Update Join Requests UI from full data object
  function updateJoinRequestsUIFromData(data) {
      if (data && data.count_text) {
          joinRequestsCount.textContent = data.count_text;
          
          if (data.has_requests && data.count_text !== '0') {
             joinRequestsDot.className = 'status-dot configured';
          } else {
             joinRequestsDot.className = 'status-dot';
          }
      }
  }

  // Render notifications list
  function renderNotifications(notifications, isStale = false) {
      if (!notifications || notifications.length === 0) {
        notificationList.innerHTML = '<div class="notification-item" style="opacity: 0.5;"><div class="notification-time">No notifications</div><div class="notification-text">You\'re all caught up!</div></div>';
        return;
      }

      notificationList.innerHTML = '';

      notifications.forEach((notif) => {
        const item = document.createElement('div');
        item.className = 'notification-item';

        // Make entire item clickable if URL exists
        if (notif.url) {
            item.style.cursor = 'pointer';
            item.addEventListener('click', () => {
                chrome.tabs.create({ url: notif.url });
            });
        }

        const time = document.createElement('div');
        time.className = 'notification-time';
        time.textContent = notif.time_ago || 'Just now';

        const text = document.createElement('div');
        text.className = 'notification-text';

        const author = document.createElement('strong');
        author.textContent = notif.user_name || 'Someone';
        text.appendChild(author);

        const action = document.createTextNode(` ${notif.action || 'commented'}`);
        text.appendChild(action);

        if (notif.post_title) {
          const postTitle = document.createTextNode(` on "${notif.post_title}"`);
          text.appendChild(postTitle);
        }

        item.appendChild(time);
        item.appendChild(text);
        notificationList.appendChild(item);
      });
  }

  // Render messages list
  function renderMessages(messages, isStale = false) {
      const unreadMessages = messages.filter(msg => msg.is_unread);
      const readMessages = messages.filter(msg => !msg.is_unread);
      const allMessages = [...unreadMessages, ...readMessages];

      if (allMessages.length === 0) {
        messagesList.innerHTML = '<div class="notification-item" style="opacity: 0.5;"><div class="notification-time">No messages</div><div class="notification-text">No recent messages</div></div>';
        return;
      }

      messagesList.innerHTML = '';

      unreadMessages.forEach((msg) => {
        const item = document.createElement('div');
        item.className = 'notification-item';

        if (msg.url) {
            item.style.cursor = 'pointer';
            item.addEventListener('click', () => {
                chrome.tabs.create({ url: msg.url });
            });
        }

        const time = document.createElement('div');
        time.className = 'notification-time';
        time.textContent = msg.time_ago || 'Just now';

        const text = document.createElement('div');
        text.className = 'notification-text';

        const author = document.createElement('strong');
        author.textContent = msg.user_name || 'Someone';
        text.appendChild(author);

        const preview = document.createElement('span');
        preview.textContent = msg.message_preview ? `: ${msg.message_preview}` : '';
        text.appendChild(preview);

        item.appendChild(time);
        item.appendChild(text);
        messagesList.appendChild(item);
      });

      readMessages.forEach((msg) => {
        const item = document.createElement('div');
        item.className = 'notification-item';

        if (msg.url) {
            item.style.cursor = 'pointer';
            item.addEventListener('click', () => {
                chrome.tabs.create({ url: msg.url });
            });
        }

        const time = document.createElement('div');
        time.className = 'notification-time';
        time.textContent = msg.time_ago || 'Just now';

        const text = document.createElement('div');
        text.className = 'notification-text';

        const author = document.createElement('strong');
        author.textContent = msg.user_name || 'Someone';
        text.appendChild(author);

        const preview = document.createElement('span');
        preview.textContent = msg.message_preview ? `: ${msg.message_preview}` : '';
        text.appendChild(preview);

        item.appendChild(time);
        item.appendChild(text);
        messagesList.appendChild(item);
      });
   }

   // Listen for real-time updates from background.js
   chrome.runtime.onMessage.addListener((message) => {
      if (message.type === 'NOTIFICATIONS_UPDATED') {
            console.log('Popup received notifications update');
            if (message.count !== undefined) {
                unreadCount.textContent = message.count;
                savedStats.unreadCount = message.count;
            }
            if (message.notifications) {
                renderNotifications(message.notifications);
            }
            // Stop spinner if running
            refreshMonitor.style.transform = '';
            if (refreshMonitorList) refreshMonitorList.style.transform = '';
        }

         if (message.type === 'MESSAGES_UPDATED') {
            console.log('Popup received messages update');
            if (message.messagesCount !== undefined) {
                messagesCount.textContent = message.messagesCount;
                savedStats.messagesCount = message.messagesCount;
            }
            if (message.messagesCountUnread !== undefined) {
                messagesUnreadBadge.textContent = message.messagesCountUnread;
                if (message.messagesCountUnread > 0) {
                  messagesUnreadBadge.style.display = 'inline-block';
                } else {
                  messagesUnreadBadge.style.display = 'none';
                }
                savedStats.messagesCountUnread = message.messagesCountUnread;
            }
            if (message.messages) {
                renderMessages(message.messages);
            }
            // Stop spinners if running
            refreshMessagesList.style.transform = '';
         }

        if (message.type === 'JOIN_REQUESTS_UPDATED') {
            console.log('Popup received join requests update');
            if (message.data) {
                updateJoinRequestsUIFromData(message.data);
            }
        }
    });

  // Settings management - FIXED: Now returns Promise to prevent race conditions
  async function loadSettings() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['settings'], (result) => {
        if (result.settings) {
          currentSettings = { ...currentSettings, ...result.settings };
          console.log('⚙️ Settings loaded from storage:', currentSettings);
        }

        // Update UI
        if (currentSettings.notificationsEnabled) {
          notificationsToggle.classList.add('active');
        } else {
          notificationsToggle.classList.remove('active');
        }

        if (currentSettings.desktopNotificationsEnabled) {
          desktopToggle.classList.add('active');
        } else {
          desktopToggle.classList.remove('active');
        }
        // Update desktop label color
        const desktopLabel = desktopToggle.previousElementSibling;
        if (desktopLabel && desktopLabel.classList.contains('toggle-label')) {
          desktopLabel.classList.toggle('disabled', !currentSettings.desktopNotificationsEnabled);
        }

        if (currentSettings.joinRequestsEnabled) {
          joinRequestsToggle.classList.add('active');
        } else {
          joinRequestsToggle.classList.remove('active');
        }

        if (currentSettings.messagesEnabled) {
          messagesToggle.classList.add('active');
        } else {
          messagesToggle.classList.remove('active');
        }

        checkInterval.value = currentSettings.checkInterval;

        // Load badge mode setting
        const badgeModeSelect = document.getElementById('badgeMode');
        if (badgeModeSelect) {
          badgeModeSelect.value = currentSettings.badgeMode || 'all';
        }

        // Update Join Requests visual state (Grey out if disabled)
        updateJoinRequestsUI();

        // Update Messages visual state (Grey out if disabled)
        updateMessagesUI();

        // Update lock UI
        updateLockUI();

        // Update messages toggle disabled state

        // CRITICAL FIX: Set communitySlug.value from saved settings FIRST
        // This prevents autoDetectCommunitySlug from overwriting with wrong value
        if (currentSettings.communitySlug) {
          communitySlug.value = currentSettings.communitySlug;
          console.log('🔒 Restored communitySlug from settings:', currentSettings.communitySlug);
        }

        resolve();
      });
    });
  }

  // Update Join Requests UI state (grey out if disabled)
  function updateJoinRequestsUI() {
    const isEnabled = currentSettings.joinRequestsEnabled;
    const parent = joinRequestsCount.closest('.stat-item') || joinRequestsCount.parentElement;

    if (isEnabled) {
      joinRequestsCount.classList.remove('disabled-text');
      if (parent) parent.classList.remove('disabled-stat');
      joinRequestsDot.style.opacity = '1';
    } else {
      joinRequestsCount.classList.add('disabled-text');
      if (parent) parent.classList.add('disabled-stat');
      joinRequestsDot.style.opacity = '0.3';
      joinRequestsCount.textContent = 'OFF';
    }
  }

  // Update Messages UI state (grey out if disabled)
  function updateMessagesUI() {
    const isEnabled = currentSettings.messagesEnabled;
    const parent = messagesCount.closest('.stat-item') || messagesCount.parentElement;

    if (isEnabled) {
      messagesCount.classList.remove('disabled-text');
      if (parent) parent.classList.remove('disabled-stat');
      messagesDot.style.opacity = '1';
    } else {
      messagesCount.classList.add('disabled-text');
      if (parent) parent.classList.add('disabled-stat');
      messagesDot.style.opacity = '0.3';
      messagesCount.textContent = 'OFF';
    }
  }

  // Update lock UI based on current state
  function updateLockUI() {
    if (currentSettings.communitySlugLocked) {
      // Locked state - closed padlock
      lockCommunity.classList.add('locked');
      lockCommunity.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>';
      communitySlug.classList.add('locked');
      communitySlug.disabled = true;
      lockStatus.textContent = 'Locked';
      lockStatus.style.color = 'var(--c-accent)';
      communityStatus.textContent = 'Locked - will not auto-detect';
    } else {
      // Unlocked state - open padlock
      lockCommunity.classList.remove('locked');
      lockCommunity.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 9.9-1"/></svg>';
      communitySlug.classList.remove('locked');
      communitySlug.disabled = false;
      lockStatus.textContent = 'Unlocked';
      lockStatus.style.color = 'var(--c-accent)';
      communityStatus.textContent = currentSettings.communitySlug ? 'Manual' : 'Auto-detected from your Skool tab';
    }
  }

  // Auto-detect community slug from current Skool tab (only if not set and not locked)
  async function autoDetectCommunitySlug() {
    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      const currentTab = tabs[0];

      // CRITICAL: Always use saved value first - don't auto-detect if already set
      if (currentSettings.communitySlug) {
        communitySlug.value = currentSettings.communitySlug;
        console.log('✅ Using saved communitySlug:', currentSettings.communitySlug);
        return; // Already has community slug, no need to detect
      }

      // If locked, don't auto-detect even if empty
      if (currentSettings.communitySlugLocked) {
        communitySlug.value = currentSettings.communitySlug || '';
        console.log('🔒 Community locked, using:', currentSettings.communitySlug || '(empty)');
        return;
      }

      // Auto-detect from URL if on Skool and no slug is saved yet
      if (currentTab.url && currentTab.url.includes('skool.com/')) {
        // Extract community slug from URL
        const urlMatch = currentTab.url.match(/skool\.com\/([^\/]+)/);
        if (urlMatch && urlMatch[1]) {
          const detectedSlug = urlMatch[1];

          // Only auto-save if no slug is saved yet (double-check)
          if (!currentSettings.communitySlug) {
            console.log('🔍 Auto-detected communitySlug:', detectedSlug);
            currentSettings.communitySlug = detectedSlug;
            communitySlug.value = detectedSlug;

            // Save to storage
            chrome.storage.local.set({ settings: currentSettings });

            // Update messages toggle disabled state after auto-detection
              }
        }
      }
    } catch (error) {
      console.error('Error auto-detecting community slug:', error);
      // Fallback to saved value
      if (currentSettings.communitySlug) {
        communitySlug.value = currentSettings.communitySlug;
      }
    }
  }

  function saveSettingsToStorage() {
    chrome.storage.local.set({ settings: currentSettings }, () => {
      // Show save confirmation
      const btn = saveSettings;
      const originalText = btn.textContent;
      btn.textContent = '✅ Saved!';

      setTimeout(() => {
        btn.textContent = originalText;
      }, 1500);

      // Notify background script
      chrome.runtime.sendMessage({
        type: 'UPDATE_SETTINGS',
        settings: currentSettings
      });
    });
  }

  // Event listeners
  function setupEventListeners() {
    // Notifications toggle
    notificationsToggle.addEventListener('click', () => {
      currentSettings.notificationsEnabled = !currentSettings.notificationsEnabled;
      notificationsToggle.classList.toggle('active');
      saveSettingsToStorage();
    });

    // Desktop toggle
    desktopToggle.addEventListener('click', () => {
      currentSettings.desktopNotificationsEnabled = !currentSettings.desktopNotificationsEnabled;
      desktopToggle.classList.toggle('active');
      // Update label color
      const desktopLabel = desktopToggle.previousElementSibling;
      if (desktopLabel && desktopLabel.classList.contains('toggle-label')) {
        desktopLabel.classList.toggle('disabled', !currentSettings.desktopNotificationsEnabled);
      }
      saveSettingsToStorage();
    });

    // Join requests toggle
    joinRequestsToggle.addEventListener('click', () => {
      currentSettings.joinRequestsEnabled = !currentSettings.joinRequestsEnabled;
      joinRequestsToggle.classList.toggle('active');
      updateJoinRequestsUI(); // Update dashboard immediately
      saveSettingsToStorage();
    });

    // Messages toggle - NOW ENABLED
    messagesToggle.addEventListener('click', () => {
      currentSettings.messagesEnabled = !currentSettings.messagesEnabled;
      messagesToggle.classList.toggle('active');
      updateMessagesUI(); // Update dashboard immediately
      saveSettingsToStorage();
    });

    // Badge mode selector
    const badgeModeSelect = document.getElementById('badgeMode');
    if (badgeModeSelect) {
      badgeModeSelect.addEventListener('change', () => {
        currentSettings.badgeMode = badgeModeSelect.value;
        saveSettingsToStorage();
      });
    }

    // Save settings button
    saveSettings.addEventListener('click', () => {
      const interval = parseInt(checkInterval.value);
      if (interval < 5 || interval > 1000) {
        alert('Check interval must be between 5 and 1000 minutes');
        return;
      }
      currentSettings.checkInterval = interval;

      // Only update communitySlug if NOT locked
      if (!currentSettings.communitySlugLocked) {
        currentSettings.communitySlug = communitySlug.value.trim();
      }

      saveSettingsToStorage();
    });

    // Save community
    saveCommunity.addEventListener('click', () => {
      const slug = communitySlug.value.trim();
      if (!slug) {
        alert('Please enter your community slug first');
        return;
      }

      // Auto-unlock when manually saving community
      if (currentSettings.communitySlugLocked) {
        currentSettings.communitySlugLocked = false;
      }

      currentSettings.communitySlug = slug;
      saveSettingsToStorage();
      updateLockUI();
    });

    // Lock/unlock community slug
    lockCommunity.addEventListener('click', () => {
      currentSettings.communitySlugLocked = !currentSettings.communitySlugLocked;

      // If locking, save current value
      if (currentSettings.communitySlugLocked) {
        currentSettings.communitySlug = communitySlug.value.trim();
      }

      // Update UI
      updateLockUI();

      // Save to storage
      chrome.storage.local.set({ settings: currentSettings });
    });

    // Refresh tokens
    refreshTokens.addEventListener('click', extractTokens);

    // Copy tokens
    copyTokens.addEventListener('click', copyTokensToClipboard);

    // Visit site
    visitSite.addEventListener('click', () => {
      const utmUrl = 'https://skapi.pro?utm_source=chrome_extension&utm_medium=popup&utm_campaign=quick_actions';
      chrome.tabs.create({ url: utmUrl });
    });

    // Unified refresh handler
    const triggerManualRefresh = (btn) => {
      // Add spinning animation
      btn.style.transform = 'rotate(360deg)';
      btn.style.transition = 'transform 1s ease';
      
      // Trigger check via background script
      chrome.runtime.sendMessage({ type: 'CHECK_NOW' }, (response) => {
           console.log('Manual check triggered');
           // Timeout as fallback to stop spinning
           setTimeout(() => {
               btn.style.transform = '';
           }, 2000);
      });
    };

    // Refresh monitor (Dashboard)
    refreshMonitor.addEventListener('click', () => {
      triggerManualRefresh(refreshMonitor);
    });

    // Refresh monitor (Monitor Page)
    if (refreshMonitorList) {
        refreshMonitorList.addEventListener('click', () => {
          triggerManualRefresh(refreshMonitorList);
        });
    }

    // Refresh messages (Monitor Page) - triggers background check
    if (refreshMessagesList) {
        refreshMessagesList.addEventListener('click', () => {
          triggerManualRefresh(refreshMessagesList);
        });
    }

    // Refresh usage plan
    if (refreshUsage) {
      refreshUsage.addEventListener('click', () => {
        refreshUsage.style.transform = 'rotate(360deg)';
        refreshUsage.style.transition = 'transform 1s ease';
        fetchUsagePlan();
        setTimeout(() => {
          refreshUsage.style.transform = '';
        }, 1000);
      });
    }

    // Stop spinners when update received
    chrome.runtime.onMessage.addListener((message) => {
        if (message.type === 'NOTIFICATIONS_UPDATED') {
            refreshMonitor.style.transform = '';
            if (refreshMonitorList) refreshMonitorList.style.transform = '';
        }
        if (message.type === 'MESSAGES_UPDATED') {
            if (refreshMessagesList) refreshMessagesList.style.transform = '';
        }
    });

    // Click-to-reveal user_id
    userId.addEventListener('click', () => {
      if (fullUserId) {
        navigator.clipboard.writeText(fullUserId);
        userId.textContent = '✓ Copied!';
        setTimeout(() => {
          userId.textContent = fullUserId;
        }, 1000);
      }
    });

    // Click-to-reveal jwt_token
    jwtToken.addEventListener('click', () => {
      if (fullJwtToken) {
        navigator.clipboard.writeText(fullJwtToken);
        jwtToken.textContent = '✓ Copied!';
        setTimeout(() => {
          jwtToken.textContent = maskJwtToken(fullJwtToken);
        }, 1000);
      }
    });
  }

  // Token extraction
  async function extractTokens() {
    try {
      // Check for ANY skool.com tab (not just active one)
      const tabs = await chrome.tabs.query({ url: '*://*.skool.com/*' });

      if (tabs.length === 0) {
        showTokenStatus('No Skool Tab', false);
        return;
      }

      // Get cookies (don't need active tab, just need to be logged into Skool somewhere)
      const cookies = await chrome.cookies.getAll({ domain: '.skool.com' });
      const clientIdCookie = cookies.find(c => c.name === 'client_id');
      const authTokenCookie = cookies.find(c => c.name === 'auth_token');

      if (!authTokenCookie) {
        showTokenStatus('Not Logged In', false);
        return;
      }

      fullJwtToken = authTokenCookie.value;
      const clientIdValue = clientIdCookie ? clientIdCookie.value : '';

      // Decode JWT
      const parts = fullJwtToken.split('.');
      if (parts.length !== 3) {
        showTokenStatus('Invalid Token', false);
        return;
      }

      const payload = JSON.parse(atob(parts[1]));
      fullUserId = payload.user_id || 'Unknown';
      const exp = payload.exp ? new Date(payload.exp * 1000) : null;
      const iat = payload.iat ? new Date(payload.iat * 1000) : null;

      // Check if token is valid
      const now = new Date();
      const isValid = !exp || exp > now;

      // Update UI
      showTokenStatus(isValid ? 'Valid' : 'Expired', isValid);

      // Show masked user_id
      userId.textContent = maskUserId(fullUserId);
      userId.classList.add('clickable');

      // Show masked jwt_token
      jwtToken.textContent = maskJwtToken(fullJwtToken);
      jwtToken.classList.add('clickable');

      if (exp) {
        expiryDate.textContent = exp.toLocaleString();
      }

    } catch (error) {
      console.error('Error extracting tokens:', error);
      showTokenStatus('Error', false);
    }
  }

  // Mask user_id for display
  function maskUserId(userId) {
    if (!userId || userId === 'Unknown') return '--';
    if (userId.length <= 10) return userId;
    return userId.substring(0, 6) + '...' + userId.substring(userId.length - 4);
  }

  // Mask jwt_token for display
  function maskJwtToken(token) {
    if (!token) return '--';
    if (token.length <= 20) return token;
    return token.substring(0, 10) + '...' + token.substring(token.length - 10);
  }

  function showTokenStatus(status, isValid) {
    tokenStatus.textContent = '';
    const span = document.createElement('span');
    span.className = isValid ? 'status-valid' : 'status-invalid';
    span.textContent = status;
    tokenStatus.appendChild(span);
  }

  // Update service status based on configuration
  function updateServiceStatus() {
    // Check if notifications are enabled
    if (!currentSettings.notificationsEnabled) {
      serviceStatusDot.className = 'status-dot warning';
      serviceStatusText.textContent = 'Notifications disabled';
      return;
    }

    // Check if community slug is set
    if (!currentSettings.communitySlug) {
      serviceStatusDot.className = 'status-dot warning';
      serviceStatusText.textContent = 'Community not configured';
      return;
    }

    // Check if user is logged in (has JWT token)
    if (!fullJwtToken) {
      serviceStatusDot.className = 'status-dot warning';
      serviceStatusText.textContent = 'Not logged in to Skool';
      return;
    }

    // All checks passed - service is configured
    serviceStatusDot.className = 'status-dot configured';
    serviceStatusText.textContent = 'Service connected & monitoring';
  }

  // Save stats to chrome.storage
  function saveStatsToStorage() {
    savedStats.lastUpdated = Date.now();
    chrome.storage.local.set({ notificationStats: savedStats });
    console.log('💾 Stats saved:', savedStats);
  }

  // Load stats from chrome.storage and update UI
  function loadStatsFromStorage() {
    chrome.storage.local.get(['notificationStats'], (result) => {
      if (result.notificationStats) {
        savedStats = result.notificationStats;
        console.log('📂 Stats loaded:', savedStats);

        // Update UI with saved values
        if (savedStats.unreadCount !== null) {
          unreadCount.textContent = savedStats.unreadCount;
        }
        if (savedStats.joinRequestsCount !== null) {
          joinRequestsCount.textContent = savedStats.joinRequestsCount;
        }
        // Update dot color based on join requests count
        if (savedStats.joinRequestsCount !== null && savedStats.joinRequestsCount !== '0' && savedStats.joinRequestsCount !== 0) {
          joinRequestsDot.className = 'status-dot configured';
        } else {
          joinRequestsDot.className = 'status-dot';
        }
        
        // Final check for disabled state
        updateJoinRequestsUI();
      }
    });
  }

   // Load notifications from storage (deprecated - data is now fetched from background)
   function loadNotifications() {
     // Data is now fetched from background in fetchFreshStatsFromBackground()
     // No API call needed - prevents delay and syncs with badge
     // This function is kept for backward compatibility
   }

  // Check join requests count
  async function checkJoinRequestsCount(jwtToken) {
    try {
      if (!currentSettings.communitySlug) {
        console.log('No community slug configured, skipping join requests check');
        joinRequestsCount.textContent = '0';
        joinRequestsDot.className = 'status-dot';
        return;
      }

      console.log('Checking join requests for community:', currentSettings.communitySlug);

      // Get all cookies for proper authentication
      const cookies = await chrome.cookies.getAll({ domain: '.skool.com' });

      const response = await fetch('https://skoolpublikgroupchecker-production.up.railway.app/check-join-requests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          group: currentSettings.communitySlug,
          jwt_token: jwtToken,
          cookies: cookies
        })
      });

      console.log('Join requests API response status:', response.status);

      if (response.ok) {
        const data = await response.json();
        console.log('Join requests data:', data);

        if (data.join_requests) {
          const hasRequests = data.join_requests.has_requests;
          const countText = data.join_requests.count_text;

          joinRequestsCount.textContent = countText;
          savedStats.joinRequestsCount = countText;
          saveStatsToStorage();

          if (hasRequests && countText !== '0') {
            joinRequestsDot.className = 'status-dot configured';
          } else {
            joinRequestsDot.className = 'status-dot';
          }
        } else {
          joinRequestsCount.textContent = '0';
          savedStats.joinRequestsCount = '0';
          saveStatsToStorage();
          joinRequestsDot.className = 'status-dot';
        }
      } else {
        console.error('Join requests API error:', response.status, response.statusText);
        joinRequestsCount.textContent = 'N/A';
        joinRequestsDot.className = 'status-dot warning';
      }
    } catch (error) {
      console.error('Error checking join requests:', error);
      joinRequestsCount.textContent = 'N/A';
      joinRequestsDot.className = 'status-dot warning';
    }
  }

  // Copy tokens to clipboard
  async function copyTokensToClipboard() {
    try {
      const cookies = await chrome.cookies.getAll({ domain: '.skool.com' });
      const clientIdCookie = cookies.find(c => c.name === 'client_id');
      const authTokenCookie = cookies.find(c => c.name === 'auth_token');

      if (!authTokenCookie) {
        alert('No auth_token found. Please login to Skool first.');
        return;
      }

      const jwtToken = authTokenCookie.value;
      const clientIdValue = clientIdCookie ? clientIdCookie.value : '';

      const tokensText = `Client ID:\n${clientIdValue}\n\nJWT Token:\n${jwtToken}`;

      await navigator.clipboard.writeText(tokensText);
      alert('✅ Tokens copied to clipboard!');
    } catch (error) {
      console.error('Error copying tokens:', error);
      alert('❌ Failed to copy tokens: ' + error.message);
    }
  }

  // Fetch usage plan from API
  async function fetchUsagePlan() {
    try {
      if (!chrome || !chrome.storage) {
        console.error('❌ chrome.storage not available');
        return;
      }

      // Get JWT token from storage (saved by background.js)
      chrome.storage.local.get(['jwtToken'], async (result) => {
        if (!result.jwtToken) {
          console.log('No JWT token found, skipping plan fetch');
          return;
        }

        const fetchWithRetry = async (attempt = 0) => {
          const maxAttempts = 3;
          const delays = [1000, 2000, 5000];

          try {
            const response = await fetch('https://skoolpublikgroupchecker-production.up.railway.app/quota/plan?jwt_token=' + encodeURIComponent(result.jwtToken));

            if (!response.ok) {
              if (response.status >= 500 && attempt < maxAttempts - 1) {
                const delay = delays[attempt] || 5000;
                console.warn(`⚠️ API error ${response.status}, retrying in ${delay}ms...`);
                setTimeout(() => fetchWithRetry(attempt + 1), delay);
                return;
              }
              console.error('❌ Failed to fetch plan:', response.status);
              loadPlanFromStorage();
              return;
            }

            const data = await response.json();

            // Update UI with plan data
            if (data.plan) {
              planName.textContent = data.plan.toUpperCase();
            }

            if (data.usage) {
              const usage = data.usage;
              monthlyUsed.textContent = usage.monthly_used || 0;
              monthlyQuota.textContent = data.monthly_quota || 0;
              monthlyRemaining.textContent = usage.monthly_remaining || 0;

              // Update rate limit info
              const rateLimit = data.rate_limit_per_minute || 0;
              rateLimitInfo.textContent = `${rateLimit} requests/min`;
            }

            // Save to storage for persistence
            chrome.storage.local.set({ usagePlanData: data });
          } catch (error) {
            console.error('❌ Error fetching usage plan:', error);
            if (error.name === 'TypeError' && attempt < maxAttempts - 1) {
              const delay = delays[attempt] || 5000;
              console.warn(`⚠️ Network error, retrying in ${delay}ms...`);
              setTimeout(() => fetchWithRetry(attempt + 1), delay);
            } else {
              loadPlanFromStorage();
            }
          }
        };

        fetchWithRetry();
      });
    } catch (error) {
      console.error('Error in fetchUsagePlan:', error);
    }
  }

  function loadPlanFromStorage() {
    // Load from storage as fallback
    chrome.storage.local.get(['usagePlanData'], (storageResult) => {
      if (storageResult.usagePlanData) {
        const data = storageResult.usagePlanData;
        if (data.plan) planName.textContent = data.plan.toUpperCase();
        if (data.usage) {
          monthlyUsed.textContent = data.usage.monthly_used || 0;
          monthlyQuota.textContent = data.monthly_quota || 0;
          monthlyRemaining.textContent = data.usage.monthly_remaining || 0;
        }
        if (data.rate_limit_per_minute) {
          rateLimitInfo.textContent = `${data.rate_limit_per_minute} requests/min`;
        }
      }
    });
  }
});
